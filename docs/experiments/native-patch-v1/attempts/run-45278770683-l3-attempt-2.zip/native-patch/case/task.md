Plan six periods of operation for a fictitious classroom water storage tank.

Read `input/site.json` for initial storage, bounds, and the allowable discrete
pump volumes. Read `input/periods.csv` for demand, pump availability, and the
tariff in each period.

Choose one pump volume for each period. It must be an allowed volume and at
most that period's pump limit. End-of-period storage is the preceding storage
plus that period's pumped volume minus that period's demand. Meet all demand,
use the same storage bounds in every period, and finish within the specified
final storage bounds. All bounds are inclusive. Pumping costs the number of
units pumped times the period's tariff. Among feasible schedules, minimize
total pumping cost. Any schedule tied for minimum cost is acceptable.

Save these two files under `output/`.

- `output/schedule.csv` has the exact header
  `period,pump_units,end_storage_units,period_cost_cents` and one row per period
  in period order. Write all four values as base-10 integers.
- `output/summary.json` is a JSON object containing exactly the three integer
  fields `total_pump_units`, `final_storage_units`, and `total_cost_cents`.
